<script setup>
import { RouterView } from "vue-router";
</script>

<template>
  <router-view />
</template>

<style>
html, body {
  margin: 0;
  padding: 0;
  overflow-x: hidden;
  width: 100%;
  box-sizing: border-box;
}
* {
  box-sizing: inherit;
}
</style>
