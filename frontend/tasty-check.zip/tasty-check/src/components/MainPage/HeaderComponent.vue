<template>
    <header class="relative">
        <slot></slot>
    </header>
</template>

<script setup>
// O componente é simples e apenas serve como um wrapper
</script>

<style scoped>
/* Estilo mantido minimalista já que o conteúdo vem via slot do HomePage */
</style>