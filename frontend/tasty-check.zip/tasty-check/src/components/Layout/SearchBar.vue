<template>
  <div class="relative w-full max-w-md">
    <input
      type="text"
      placeholder="Pesquisar restaurantes..."
      class="w-full px-4 py-2 rounded-full border focus:outline-none focus:ring-2 focus:ring-green-600"
    />
    <i class="fas fa-search absolute right-3 top-2.5 text-gray-400"></i>
  </div>
</template>
